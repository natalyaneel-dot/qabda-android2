package qabda.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private val views = mutableListOf<Pair<Pad, View>>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        TouchMap.ensure(this)
        startInForeground()
        TouchMap.onChange = { rebuild() }
        rebuild()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        rebuild()
        return START_STICKY
    }

    override fun onDestroy() {
        TouchMap.onChange = null
        views.forEach { runCatching { windowManager.removeView(it.second) } }
        views.clear()
        super.onDestroy()
    }

    private fun startInForeground() {
        val channelId = "qabda"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, getString(R.string.channel), NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notice))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun flags(): Int {
        var value = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!TouchMap.editing) value = value or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return value
    }

    private fun rebuild() {
        views.forEach { runCatching { windowManager.removeView(it.second) } }
        views.clear()
        val size = TouchMap.padSizePx(this)
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        TouchMap.pads.forEach { pad ->
            val view = TextView(this).apply {
                text = pad.label
                gravity = Gravity.CENTER
                setTextColor(0xFF1A2208.toInt())
                textSize = 12f
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xE6D6FF4A.toInt())
                }
                setOnTouchListener { touched, event -> drag(pad, touched, event) }
            }
            val params = WindowManager.LayoutParams(size, size, type, flags(), PixelFormat.TRANSLUCENT)
            params.gravity = Gravity.TOP or Gravity.START
            params.x = pad.x
            params.y = pad.y
            windowManager.addView(view, params)
            views += pad to view
        }
    }

    private fun drag(pad: Pad, view: View, event: MotionEvent): Boolean {
        if (!TouchMap.editing) return false
        val params = view.layoutParams as WindowManager.LayoutParams
        val tag = view.tag as? IntArray ?: IntArray(4)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tag[0] = event.rawX.toInt()
                tag[1] = event.rawY.toInt()
                tag[2] = params.x
                tag[3] = params.y
                view.tag = tag
                TouchMap.selectedId = pad.id
            }
            MotionEvent.ACTION_MOVE -> {
                params.x = tag[2] + (event.rawX.toInt() - tag[0])
                params.y = tag[3] + (event.rawY.toInt() - tag[1])
                pad.x = params.x
                pad.y = params.y
                windowManager.updateViewLayout(view, params)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> TouchMap.save(this)
        }
        return true
    }
}

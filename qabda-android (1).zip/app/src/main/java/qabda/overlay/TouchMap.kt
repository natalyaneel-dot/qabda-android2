package qabda.overlay

import android.content.Context
import android.util.TypedValue
import org.json.JSONArray
import org.json.JSONObject

data class Pad(
    val id: String,
    var keyCode: Int,
    var label: String,
    var x: Int,
    var y: Int,
    var delayMs: Int,
    var turboHz: Int,
)

object TouchMap {
    var editing: Boolean = true
    var selectedId: String? = null
    val pads = mutableListOf<Pad>()
    var onChange: (() -> Unit)? = null

    private val catalog = listOf(
        96 to "إكس",
        97 to "دائرة",
        99 to "مربع",
        100 to "مثلث",
        102 to "L1",
        103 to "R1",
        104 to "L2",
        105 to "R2",
        106 to "L3",
        107 to "R3",
        19 to "↑",
        20 to "↓",
        21 to "←",
        22 to "→",
        109 to "Create",
        108 to "Options",
        110 to "Touch",
    )

    fun padSizePx(context: Context): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            56f,
            context.resources.displayMetrics,
        ).toInt()
    }

    fun ensure(context: Context) {
        if (pads.isNotEmpty()) return
        load(context)
        if (pads.isNotEmpty()) return
        val width = context.resources.displayMetrics.widthPixels
        val height = context.resources.displayMetrics.heightPixels
        val cols = floatArrayOf(0.08f, 0.32f, 0.56f, 0.80f)
        val rows = floatArrayOf(0.10f, 0.26f, 0.42f, 0.58f, 0.74f)
        catalog.forEachIndexed { index, item ->
            val col = index % 4
            val row = index / 4
            pads += Pad(
                id = "p$index",
                keyCode = item.first,
                label = item.second,
                x = (width * cols[col]).toInt().coerceAtLeast(0),
                y = (height * rows[row]).toInt().coerceAtLeast(0),
                delayMs = 0,
                turboHz = 0,
            )
        }
        selectedId = pads.first().id
        val limit = padSizePx(context)
        pads.forEach { pad ->
            pad.x = pad.x.coerceIn(0, (width - limit).coerceAtLeast(0))
            pad.y = pad.y.coerceIn(0, (height - limit).coerceAtLeast(0))
        }
        save(context)
    }

    fun addNext(context: Context) {
        ensure(context)
        if (pads.size >= 12) return
        val used = pads.map { it.keyCode }.toSet()
        val next = catalog.firstOrNull { it.first !in used } ?: catalog.first()
        val width = context.resources.displayMetrics.widthPixels
        val height = context.resources.displayMetrics.heightPixels
        val pad = Pad(
            id = "p${System.currentTimeMillis()}",
            keyCode = next.first,
            label = next.second,
            x = width / 2,
            y = height / 3,
            delayMs = 0,
            turboHz = 0,
        )
        pads += pad
        selectedId = pad.id
        save(context)
        onChange?.invoke()
    }

    fun duplicateSelected(context: Context) {
        ensure(context)
        val source = pads.find { it.id == selectedId } ?: pads.firstOrNull() ?: return
        if (pads.size >= 12) return
        val copy = source.copy(
            id = "p${System.currentTimeMillis()}",
            x = source.x + padSizePx(context),
            y = source.y + 24,
            delayMs = 160,
        )
        pads += copy
        selectedId = copy.id
        save(context)
        onChange?.invoke()
    }

    fun save(context: Context) {
        val array = JSONArray()
        pads.forEach { pad ->
            array.put(
                JSONObject()
                    .put("id", pad.id)
                    .put("key", pad.keyCode)
                    .put("label", pad.label)
                    .put("x", pad.x)
                    .put("y", pad.y)
                    .put("delay", pad.delayMs)
                    .put("turbo", pad.turboHz),
            )
        }
        context.getSharedPreferences("qabda.v2", Context.MODE_PRIVATE)
            .edit()
            .putString("pads", array.toString())
            .putBoolean("editing", editing)
            .apply()
    }

    fun load(context: Context) {
        val prefs = context.getSharedPreferences("qabda.v2", Context.MODE_PRIVATE)
        editing = prefs.getBoolean("editing", true)
        val raw = prefs.getString("pads", null) ?: return
        val array = JSONArray(raw)
        pads.clear()
        for (index in 0 until array.length()) {
            val item = array.getJSONObject(index)
            val label = item.optString("label")
            if (label.isBlank()) continue
            pads += Pad(
                id = item.getString("id"),
                keyCode = item.getInt("key"),
                label = label,
                x = item.getInt("x"),
                y = item.getInt("y"),
                delayMs = item.optInt("delay"),
                turboHz = item.optInt("turbo"),
            )
        }
        if (selectedId == null) selectedId = pads.firstOrNull()?.id
    }
}

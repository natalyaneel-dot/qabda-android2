package qabda.overlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class QabdaA11yService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val loops = mutableMapOf<Int, Runnable>()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        TouchMap.ensure(this)
        val pads = TouchMap.pads.filter { it.keyCode == event.keyCode }
        if (pads.isEmpty()) return false
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount > 0) return true
                pads.forEach { pad ->
                    handler.postDelayed({ fire(pad) }, pad.delayMs.coerceIn(0, 500).toLong())
                }
                startTurbo(event.keyCode, pads)
                return true
            }
            KeyEvent.ACTION_UP -> {
                loops.remove(event.keyCode)?.let { handler.removeCallbacks(it) }
                return true
            }
        }
        return false
    }

    private fun startTurbo(keyCode: Int, pads: List<Pad>) {
        val hz = pads.maxOf { it.turboHz }
        if (hz <= 0) return
        loops.remove(keyCode)?.let { handler.removeCallbacks(it) }
        val task = object : Runnable {
            override fun run() {
                if (loops[keyCode] !== this) return
                pads.forEach { fire(it) }
                handler.postDelayed(this, 1000L / hz.coerceIn(4, 20))
            }
        }
        loops[keyCode] = task
        handler.postDelayed(task, 1000L / hz.coerceIn(4, 20))
    }

    private fun fire(pad: Pad) {
        val size = TouchMap.padSizePx(this).toFloat()
        val x = pad.x + size / 2f
        val y = pad.y + size / 2f
        val (dx, dy, duration) = when (pad.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> Triple(0f, -140f, 170L)
            KeyEvent.KEYCODE_DPAD_DOWN -> Triple(0f, 140f, 170L)
            KeyEvent.KEYCODE_DPAD_LEFT -> Triple(-140f, 0f, 170L)
            KeyEvent.KEYCODE_DPAD_RIGHT -> Triple(140f, 0f, 170L)
            else -> Triple(2f, 2f, 55L)
        }
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x + dx, y + dy)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}

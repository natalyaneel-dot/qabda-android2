package qabda.overlay

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TouchMap.ensure(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 21)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dp(20)
            setPadding(pad, dp(28), pad, pad)
        }
        root.addView(title("قبضة"))
        root.addView(note("حط الأزرار الليمونية فوق أزرار اللعبة. في الترتيب تسحبها. في اللعب تصير لمسة من اليد."))
        root.addView(button("السماح بالظهور فوق التطبيقات") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(button("تفعيل قراءة اليد") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("إظهار الأزرار") { showOverlay() })
        root.addView(button("إخفاء الأزرار") { stopService(Intent(this, OverlayService::class.java)) })
        root.addView(button("ترتيب / لعب") {
            TouchMap.editing = !TouchMap.editing
            TouchMap.save(this)
            TouchMap.onChange?.invoke()
            if (TouchMap.onChange == null) showOverlay()
        })
        root.addView(button("زر جديد") {
            TouchMap.addNext(this)
            showOverlay()
        })
        root.addView(button("غيّر اسم الزر المحدد") { renameSelected() })
        root.addView(button("تسريع الزر المحدد") { toggleTurbo() })
        root.addView(button("ادمج الزر المحدد مع لمسة ثانية") {
            TouchMap.duplicateSelected(this)
            showOverlay()
        })
        root.addView(
            note("كل أزرار اليد تظهر بأسمائها: إكس ودائرة ومربع ومثلث وL1 وR1 وL2 وR2 وL3 وR3 والأسهم وCreate وOptions وTouch. في الترتيب اسحب كل زر فوق زر اللعبة."),
        )
        setContentView(root)
    }

    private fun selectedPad() = TouchMap.pads.find { it.id == TouchMap.selectedId } ?: TouchMap.pads.firstOrNull()

    private fun renameSelected() {
        val pad = selectedPad() ?: return
        val input = EditText(this).apply {
            setText(pad.label)
            setTextColor(0xFF121410.toInt())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("اسم الزر")
            .setView(input)
            .setPositiveButton("حفظ") { _, _ ->
                val next = input.text.toString().trim()
                if (next.isEmpty() || next.length > 12) return@setPositiveButton
                pad.label = next.take(12)
                TouchMap.save(this)
                TouchMap.onChange?.invoke()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun toggleTurbo() {
        val pad = selectedPad() ?: return
        pad.turboHz = if (pad.turboHz > 0) 0 else 14
        TouchMap.save(this)
        TouchMap.onChange?.invoke()
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }

    private fun title(text: String) = TextView(this).apply {
        this.text = text
        textSize = 28f
        setTextColor(0xFFD6FF4A.toInt())
        setPadding(0, 0, 0, dp(8))
    }

    private fun note(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(0xFFA7B19E.toInt())
        setPadding(0, dp(8), 0, dp(12))
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 16f
        setOnClickListener { onClick() }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        )
        params.bottomMargin = dp(10)
        layoutParams = params
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
